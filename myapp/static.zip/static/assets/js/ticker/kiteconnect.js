// segment constants
	var NseCM = 1,
		NseFO = 2,
		NseCD = 3,
		BseCM = 4,
		BseFO = 5,
		BseCD = 6,
		McxFO = 7,
		McxSX = 8,
		Indices = 9;

	modeLTP = "ltp";
	modeFull = "full";
	modeQuote = "quote";

var ws = new WebSocket("wss://ws.kite.trade?api_key=o40me2j1newtpkip&access_token=zW5RjZ50oSp9bUZaHw09m2G0AfO3mbHK");
ws.binaryType = "arraybuffer";

var isListSet = false;

ws.onopen = function (event) {
  	var instrument_arr = JSON.parse(localStorage.getItem('all_tokens'));
	
	var message = {"a": "mode", "v": ["ltp", instrument_arr]};
	ws.send(JSON.stringify(message));
	// var message1 = {"a": "mode", "v": ["full", [55532295, 779521]]};
	// ws.send(JSON.stringify(message1));
};

function set_price(data){
	data.map((dt,index) => {
		$(`.${dt.instrument_token}_text`).html(dt.last_price)
		$(`.${dt.instrument_token}_input`).val(dt.last_price)
	})
}

ws.onmessage = function(e) {
	
	setList();
		
	// Binary tick data.
	if(parseBinary(e.data).length > 0){
		set_price(parseBinary(e.data))
	}
			if(e.data instanceof ArrayBuffer) {
				if(e.data.byteLength > 2) {
					var d = parseBinary(e.data);
					for(x in d)
					{
						$('.'+d[x].instrument_token).text(d[x].last_price);
						// console.log(typeof trading_symbol);
						if(typeof trading_symbol != 'undefined'){	$('#'+d[x].instrument_token).text( trading_symbol + ' - ' + d[x].last_price);	calc(d[x].instrument_token,d[x].last_price);}

						// console.log("IT "+d[x].instrument_token);
						if($('.'+d[x].instrument_token).val() == '')
						{
							$('.'+d[x].instrument_token).val(d[x].last_price);
						}
						$('input[type=hidden].ltp-'+d[x].instrument_token).val(d[x].last_price);
						
						calculate(d[x].instrument_token,d[x].last_price);
					}
				}
			} else {
				console.log(e);
				var price = JSON.parse(e.data).data.average_price == 0 ? JSON.parse(e.data).data.price : JSON.parse(e.data).data.average_price ;
				notifyMe(JSON.parse(e.data).data.tradingsymbol+" "+ JSON.parse(e.data).data.status + " Order at ₹ "+price);
				location.reload();
				// parseTextMessage(e.data);
			}
		};

function parseBinary(binpacks) {
		var packets = splitPackets(binpacks),
			ticks = [];

		for(var n=0; n<packets.length; n++) {
			var bin = packets[n],
				instrument_token = buf2long(bin.slice(0, 4)),
				segment = instrument_token & 0xff;

			var tradable = true;
			if (segment === Indices) tradable = false;

			var divisor = 100.0;
			if (segment === NseCD) divisor = 10000000.0;

			// Parse LTP
			if (bin.byteLength === 8) {
				// console.log("here ltp");

				ticks.push({
					tradable: tradable,
					mode: modeLTP,
					instrument_token: instrument_token,
					last_price: buf2long(bin.slice(4,8)) / divisor
				});
			// Parse indices quote and full mode
			} else if (bin.byteLength === 28 || bin.byteLength === 32) {
				// console.log("here quote");
				var mode = modeQuote;
				if (bin.byteLength === 32) mode = modeFull;

                var tick = {
                    tradable: tradable,
                    mode: mode,
                    instrument_token: instrument_token,
                    last_price: buf2long(bin.slice(4,8)) / divisor,
                    ohlc: {
                        high: buf2long(bin.slice(8, 12)) / divisor,
                        low: buf2long(bin.slice(12, 16)) / divisor,
                        open: buf2long(bin.slice(16, 20)) / divisor,
                        close: buf2long(bin.slice(20, 24)) / divisor
					},
					change: buf2long(bin.slice(24, 28))
				};

                // Compute the change price using close price and last price
                if(tick.ohlc.close != 0) {
                    tick.change = (tick.last_price - tick.ohlc.close) * 100 / tick.ohlc.close;
				}

                // Full mode with timestamp in seconds
                if (bin.byteLength === 32) {
					tick.timestamp = null;
					var timestamp = buf2long(bin.slice(28, 32));
					if (timestamp) tick.timestamp = new Date(timestamp);
				}

				ticks.push(tick);
			} else if (bin.byteLength === 44 || bin.byteLength === 184) {
				var mode = modeQuote;
				if (bin.byteLength === 184) mode = modeFull;
				// console.log("here full");

				var tick = {
                    tradable: tradable,
                    mode: mode,
                    instrument_token: instrument_token,
                    last_price: buf2long(bin.slice(4, 8)) / divisor,
                    last_quantity: buf2long(bin.slice(8, 12)),
                    average_price: buf2long(bin.slice(12, 16)) / divisor,
                    volume: buf2long(bin.slice(16, 20)),
                    buy_quantity: buf2long(bin.slice(20, 24)),
                    sell_quantity: buf2long(bin.slice(24, 28)),
                    ohlc: {
                        open: buf2long(bin.slice(28, 32)) / divisor,
                        high: buf2long(bin.slice(32, 36)) / divisor,
                        low: buf2long(bin.slice(36, 40)) / divisor,
                        close: buf2long(bin.slice(40, 44)) / divisor
                    }
				};

                // Compute the change price using close price and last price
                if (tick.ohlc.close != 0) {
                    tick.change = (tick.last_price - tick.ohlc.close) * 100 / tick.ohlc.close;
				}

				// Parse full mode
				// console.log("bit length "+bin.byteLength);
				if (bin.byteLength === 184) {

					// Parse last trade time
					tick.last_trade_time = null;
					var last_trade_time = buf2long(bin.slice(44, 48));
					if (last_trade_time) tick.last_trade_time = new Date(last_trade_time * 1000);

					// Parse timestamp
					tick.timestamp = null;
					var timestamp = buf2long(bin.slice(60, 64));
					tick.tstamp = timestamp;
					if (timestamp) tick.timestamp = new Date(timestamp * 1000);

					// Parse OI
					tick.oi = buf2long(bin.slice(48, 52));
                    tick.oi_day_high = buf2long(bin.slice(52, 56));
					tick.oi_day_low = buf2long(bin.slice(56, 60));
					tick.depth = {
						buy: [],
						sell: []
					};

					var s = 0, depth = bin.slice(64, 184);
					for (var i=0; i<10; i++) {
						s = i * 12;
						tick.depth[i < 5 ? "buy" : "sell"].push({
							quantity:	buf2long(depth.slice(s, s + 4)),
							price:		buf2long(depth.slice(s + 4, s + 8)) / divisor,
							orders: 	buf2long(depth.slice(s + 8, s + 10))
						});
					}
				}

				ticks.push(tick);
			}
		}

		return ticks;
	}

	// split one long binary message into individual tick packets
	function splitPackets(bin) {
		// number of packets
		var num = buf2long(bin.slice(0, 2)),
			j = 2,
			packets = [];

		for(var i=0; i<num; i++) {
			// first two bytes is the packet length
			var size = buf2long(bin.slice(j, j+2)),
				packet = bin.slice(j+2, j+2+size);

			packets.push(packet);

			j += 2 + size;
		}

		return packets;
	}

	function buf2long(buf) {
		var b = new Uint8Array(buf),
			val = 0,
			len = b.length;

		for(var i=0, j=len-1; i<len; i++, j--) {
			val += b[j] << (i*8);
		}

		return val;
	}

	function setList() {
		$.getJSON("http://127.0.0.1:8000/static/assets/js/ticker/options.json", function(data){
			
			var strike_price = $('.script-price').text();

			if(strike_price == null || strike_price == ""){
				return true;
			}

			// var strike_price = $('.13379330').text();

			var call_list = $('.call-list');
			var put_list = $('.put-list');
			var call_check_first_token = "";
			var put_check_first_token = "";

			strike_price = Math.round(strike_price);
			var call_options = [];
			var put_options = [];

			$('.strike_price').text(strike_price);

			for (let i = 0; i <= 5; i++) {

				var offset_price = 100 * i;
				var call_strike_price = (Math.ceil((strike_price + offset_price) / 100) * 100);
				var put_strike_price = (Math.floor((strike_price - offset_price) / 100) * 100);
				
				var sub_script_expiry = $('.script-name').data('sub_script_expiry');
				sub_script_expiry = moment(sub_script_expiry).format('YYMDD');
				var script_dropdown_val = $('#script_dropdown').val();
				// console.log(script_dropdown_val + sub_script_expiry);
				// var ce_match_string = "BANKNIFTY22113"+call_strike_price+"CE";
				var ce_match_string = script_dropdown_val + sub_script_expiry + call_strike_price+"CE";
				var ce_match_string_second = script_dropdown_val + sub_script_expiry + put_strike_price+"CE";
				var pe_match_string = script_dropdown_val + sub_script_expiry + put_strike_price+"PE";
				var pe_match_string_second = script_dropdown_val + sub_script_expiry + call_strike_price+"PE";

				
				if(ce_match_string in data) {
					call_options.push(data[ce_match_string]);
				}
				else{
					// console.log(sub_script_expiry)
					var sub_script_expiry = $('.script-name').data('sub_script_expiry');
					sub_script_expiry = moment(sub_script_expiry).format('YYMMM').toUpperCase();
					// console.log(script_dropdown_val + sub_script_expiry);
					// var ce_match_string = "BANKNIFTY22113"+call_strike_price+"CE";
					ce_match_string = script_dropdown_val + sub_script_expiry + call_strike_price+"CE";

					if(ce_match_string in data) {
						call_options.push(data[ce_match_string]);
					}
					
				}

				if(ce_match_string_second in data){
					call_options.push(data[ce_match_string_second]);
				}
				else{
					// console.log(sub_script_expiry)
					var sub_script_expiry = $('.script-name').data('sub_script_expiry');
					sub_script_expiry = moment(sub_script_expiry).format('YYMMM').toUpperCase();
					// console.log(script_dropdown_val + sub_script_expiry);
					// var ce_match_string = "BANKNIFTY22113"+call_strike_price+"CE";
					ce_match_string_second = script_dropdown_val + sub_script_expiry + put_strike_price+"CE";

					if(ce_match_string_second in data){
						call_options.push(data[ce_match_string_second]);
					}
				}
				// console.log(ce_match_string)

				if(pe_match_string in data) {
					put_options.push(data[pe_match_string]);
				}
				else{
					var sub_script_expiry = $('.script-name').data('sub_script_expiry');
					sub_script_expiry = moment(sub_script_expiry).format('YYMMM').toUpperCase();
					
					pe_match_string = script_dropdown_val + sub_script_expiry + put_strike_price+"PE";

					if(pe_match_string in data) {
						put_options.push(data[pe_match_string]);
					}
				}

				if(pe_match_string_second in data){
					put_options.push(data[pe_match_string_second]);
				}
				else{
					var sub_script_expiry = $('.script-name').data('sub_script_expiry');
					sub_script_expiry = moment(sub_script_expiry).format('YYMMM').toUpperCase();
					
					pe_match_string_second = script_dropdown_val + sub_script_expiry + call_strike_price+"PE";

					if(pe_match_string_second in data){
						put_options.push(data[pe_match_string_second]);
					}
				}
			}

			call_options =  call_options.sort(function(a, b) {
				var keyA = new Date(a.strike),
					keyB = new Date(b.strike);
				// Compare the 2 dates
				if (keyA < keyB) return -1;
				if (keyA > keyB) return 1;
				return 0;
			});

			call_check_first_token = call_options[0].instrument_token;

			put_options =  put_options.sort(function(a, b) {
				var keyA = new Date(a.strike),
					keyB = new Date(b.strike);
				// Compare the 2 dates
				if (keyA < keyB) return -1;
				if (keyA > keyB) return 1;
				return 0;
			});
			put_check_first_token = put_options[0].instrument_token;

			var callBorderPlaced = false;
			var putBorderPlaced = false;
			
			var call_list_first_item = $('#call_list_item_0').data('token');

			if(call_list_first_item != call_check_first_token){

				var call_options_list = "";
				call_options.map((data,index) => {
	
					var appendClass = '';
					var ceLlowerClass = '';
					if(strike_price < data.strike) {
						if(!callBorderPlaced) {
							appendClass = 'border-top pt-3';
							callBorderPlaced = true;
						}
						ceLlowerClass = 'ceLowerClass';
					}
	
					var appendString = `<div class="row mt-3 ${appendClass} ${ceLlowerClass}">
											<div class="col-md-8 ">
												<span style="margin-left: 0px;" id="call_list_item_${index}" data-token="${data.instrument_token}">${data.tradingsymbol.slice(-7)}</span> | <span class="${data.instrument_token}_text"></span>
											</div>
											<div class="col-md-4">
												<button data-transaction-type="buy" class="trade-btn-xs buy-btn" data-instrument_token="${data.instrument_token}" data-script_name="${data.tradingsymbol}">B</button>
												<button data-transaction-type="sell" class="trade-btn-xs sell-btn" data-instrument_token="${data.instrument_token}" data-script_name="${data.tradingsymbol}" disabled>S</button>
											</div>
										</div>`
	
					call_options_list += appendString;
				});
				call_list.html(call_options_list);
			}

			var put_list_first_item = $('#put_list_item_0').data('token');
			
			if(put_list_first_item != put_check_first_token){
				
				var put_options_list = "";
				put_options.map((data,index) => {
					var appendClass = '';
					var peLlowerClass = '';
					
					if(strike_price < data.strike) {
						if(!putBorderPlaced) {
							appendClass = 'border-top pt-3';
							putBorderPlaced = true;
						}
						peLlowerClass = 'peLowerClass';
					}

					var appendString = `<div class="row mt-3 ${appendClass} ${peLlowerClass}">
											<div class="col-md-8 ">
												<span style="margin-left: 0px;" id="put_list_item_${index}" data-token="${data.instrument_token}">${data.tradingsymbol.slice(-7)}</span> | <span class="${data.instrument_token}"></span>
											</div>
											<div class="col-md-4">
												<button data-transaction-type="buy" class="trade-btn-xs buy-btn" data-instrument_token="${data.instrument_token}" data-script_name="${data.tradingsymbol}">B</button>
												<button data-transaction-type="sell" class="trade-btn-xs sell-btn" data-instrument_token="${data.instrument_token}" data-script_name="${data.tradingsymbol}" disabled>S</button>
											</div>
										</div>`
					
					put_options_list += appendString
				});
				put_list.html(put_options_list);
			}
			
			// console.log(data.age); // Prints: 14
		}).fail(function(){
			console.log("An error has occurred.");
		});
	}
