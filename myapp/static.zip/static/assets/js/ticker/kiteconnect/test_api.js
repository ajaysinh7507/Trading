var KiteConnect = require('./lib').KiteConnect;

var apiKey = 'tfd7bg1lbl5wwhku'
var apiSecret = 'y1c83uskv1rvum5ui47dcjqnzcpqs37v'
// var apiKey = 'gvu4pixmenhmg9im'
// var apiSecret = 'qkfr1xg1gip2smdwafytppugvkhy8czj'
var requestToken = 'a9AQ8mr5EnxtfnjXCCZhGOuCkFkFz2SK'
var accessToken = ''

var k = new KiteConnect({
	api_key: apiKey
})

if (accessToken) {
	k.setAccessToken(accessToken)
	init()
} else {
	k.generateSession(requestToken, apiSecret).then(function (resp) {
		console.log(resp)
		k.setAccessToken(resp.access_token)
		init()
	}).catch(function (error) {
		console.log("error", error)
		// console.log(error)
	})
}

function init() {
	console.log('init')
	k.getMargins().then(function (resp) {
		console.log(resp)
	}).catch(function (error) {
		console.log(error)
	})
}
