// var KiteConnect = require("./lib/");

// var api_key = "x5h38ge9wfqmif5v",
// 	secret = "uesk63w8ux2k0huox5dwr2sxpe61rfb3",
// 	request_token = "AAAAA";

// kc = new KiteConnect(api_key);
// kc.requestAccessToken(request_token, secret)
// 	.then(function(resp) {
// 		console.log("Success response", resp);
// 	})
// 	.catch(function(err, resp) {
// 		console.log("Error", err.response);
// 	})


var KiteTicker = require("./lib").KiteTicker;
var ticker = new KiteTicker({
	api_key: "owgw1n3fkqk3hrcn",
	access_token: "GmRuMUQk6E4zWejyjHsoMDBFU4b0xAYv"
});

ticker.connect();
ticker.on("ticks", onTicks);
ticker.on("connect", subscribe);
ticker.on("error", onError);

function onTicks(ticks) {
	console.log("Ticks", ticks);
}

function onError(err) {
	console.log(err)
}

function subscribe() {
	var items = [256265];
	ticker.subscribe(items);
	ticker.setMode(ticker.modeFull, items);
}
