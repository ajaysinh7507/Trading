// var KiteConnect = require('../lib').KiteConnect;
// var MockAdapter = require("axios-mock-adapter");

// var kiteConnect = new KiteConnect({
// 	api_key: "someapikey"
// });

// // This sets the mock adapter on the default instance
// var mock = new MockAdapter(kiteConnect.requestInstance);

// // Mock any GET request to /users
// // arguments for reply are (status, data, headers)
// mock.onGet("/user/profile").reply(200, {
// 	"status": "success",
// 	"data": {
// 		"user_type": "investor",
// 		"email": "xxxyyy@gmail.com",
// 		"user_name": "AxAx Bxx",
// 		"user_shortname": "abc",
// 		"broker": "ZERODHA",
// 		"exchanges": [
// 			"BSE",
// 			"BFO",
// 			"NFO",
// 			"MCX",
// 			"CDS",
// 			"NSE"
// 		],
// 		"products": [
// 			"BO",
// 			"CNC",
// 			"CO",
// 			"MIS",
// 			"NRML"
// 		],
// 		"order_types": [
// 			"LIMIT",
// 			"MARKET",
// 			"SL",
// 			"SL-M"
// 		]
// 	}},
// 	{
// 		"content-type": "application/json"
// 	}
// );

// describe("Test user profile", () => {
// 	it("should load user data", () => {
// 		return kiteConnect.getProfile().then(function(resp) {
// 			expect(resp.email).toEqual("xxxyyy@gmail.com");
// 		})
// 	})
// });


var fs = require("fs");
var MockAdapter = require("axios-mock-adapter");

var mockRespBasePath = "./tests/mock-responses/";
var mockResponses = [
	// [method, status code, route uri, mock resp path, content type]
	["GET", 200, "/user/profile", "profile.json", null],
	["GET", 200, "/user/margins", "margins.json", null],
	["GET", 200, "\/users\/margins\/[a-z]+", "margins.json", null],
	["GET", 200, "/orders", "orders.json", null],
	["GET", 200, "/trades", "trades.json", null],
	["GET", 200, "\/orders\/[a-z]+", "order_info.json", null],
	["GET", 200, "\/orders\/[a-z]+\/trades", "order_trades.json", null],
	["GET", 200, "/portfolio/positions", "positions.json", null],
	["GET", 200, "/portfolio/holdings", "holdings.json", null],
	["GET", 200, "/mf/orders", "mf_orders.json", null],
	["GET", 200, "\/mf/orders\/[a-z]+", "mf_orders_info.json", null],
	["GET", 200, "/mf/sips", "mf_sips.json", null],
	["GET", 200, "\/mf/sips\/[a-z]+", "mf_sip_info.json", null],
	["GET", 200, "/mf/holdings", "mf_holdings.json", null],
	["GET", 200, "/mf/instruments", "mf_instruments.csv", "text/csv"],
	["GET", 200, "\/instruments\/[a-z]+", "instruments_nse.csv", "text/csv"],
	["GET", 200, "/instruments", "instruments_all.csv", "text/csv"],
	["GET", 200, "\/instruments\/historical\/[a-z]+\/[a-z]+", "historical_minute.json", null],
	["GET", 200, "/quote", "quote.json", null],
	["GET", 200, "/quote/ohlc", "ohlc.json", null],
	["GET", 200, "/quote/ltp", "ltp.json", null]
];

function setupMock(kiteConnect) {
	var mock = new MockAdapter(kiteConnect.requestInstance);
	mock.onAny().reply(function(config) {
		var r = mockResponses.shift();
		var headers = { "content-type": r[4] || "application/json" }
		var filePath = mockRespBasePath + r[3];
		var data = JSON.parse(fs.readFileSync(filePath, "utf8"));
		if (config.url === r[2] && config.method.toUpperCase() === r[0]) return [r[1], data, headers];
	});
}

module.exports = setupMock