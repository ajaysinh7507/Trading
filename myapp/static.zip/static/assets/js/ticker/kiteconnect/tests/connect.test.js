var KiteConnect = require("../lib").KiteConnect;
var MockAdapter = require("axios-mock-adapter");
var setupMock = require("./axios-mock-setup")

var kiteConnect = new KiteConnect({
	api_key: "someapikey"
});

setupMock(kiteConnect);

describe("Test user profile", () => {
	it("should load user data", () => {
		return kiteConnect.getProfile().then(function(resp) {
			expect(resp.email).toEqual("xxxyyy@gmail.com");
		})
	})
});

describe("Test user margins", () => {
	it("should load user margins", () => {
		return kiteConnect.getMargins().then(function(resp) {
			expect(resp).toHaveProperty("equity");
			expect(resp).toHaveProperty("commodity");
		})
	})
});