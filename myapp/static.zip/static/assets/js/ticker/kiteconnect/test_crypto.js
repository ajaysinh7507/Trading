var crypto = require("crypto");

a = {}
console.log(crypto.createHash("sha256").update(a.a).digest("hex"))