// function calculate(id, price) {
//     var v, f, y;

//     var type = $('#type' + id).val();
//     var total = $('#total' + id).val();

//     var lp;
//     var pnp = 0;
//     for (lp = 1; lp <= total; lp++) {
//         if (type == "BUY") {
//             //buy then current price = buy price
//             $("#" + id + "sp" + lp).text(price);
//             v = parseFloat(parseFloat($("#" + id + "bp" + lp).text()).toFixed(2));
//             F = parseFloat(parseFloat(price).toFixed(2));
//         }
//         else {
//             $("#" + id + "bp" + lp).text(price);
//             v = parseFloat(parseFloat(price).toFixed(2));
//             F = parseFloat(parseFloat($("#" + id + "sp" + lp).text()).toFixed(2));
//         }

//         y = parseFloat(parseFloat($("#" + id + "qty" + lp).text()).toFixed(2));
//         var t = 1.5, e = 1.5;

//         var o = v * y * 1e-4 > 20 ? 20 : parseFloat(parseFloat(v * y * 1e-4).toFixed(2)),
//             a = F * y * 1e-4 > 20 ? 20 : parseFloat(parseFloat(F * y * 1e-4).toFixed(2)),
//             i = parseFloat(parseFloat(o + a).toFixed(2)),
//             n = parseFloat(parseFloat((v + F) * y).toFixed(2)),
//             r = Math.round(parseFloat(parseFloat(F * y * 25e-5).toFixed(2))),
//             s = parseFloat(parseFloat(325e-7 * n).toFixed(2)),
//             l = 0,
//             c = parseFloat(parseFloat(.18 * (i + s)).toFixed(2)),
//             p = parseFloat(parseFloat(1e-6 * n).toFixed(2)),
//             d = parseFloat(parseFloat(i + r + s + l + c + p).toFixed(2)),
//             u = parseFloat(parseFloat(d / y).toFixed(2));
//         sd = parseFloat(parseFloat(d * 0.2).toFixed(2));
//         u = isNaN(u) ? 0 : u;
//         var np = parseFloat(parseFloat((F - v) * y - d - sd).toFixed(2));

//         pnp += np;
//         // console.log(id+"="+np);
//         $("#" + id + "np" + lp).text(np);

//     }
//     $("#tnp" + id).text(pnp);
// }

function calculate(id, price) {
    var v, f, y;

    var total = $('#total_trade').val();
    var lp;

    for (lp = 0; lp <= total; lp++) {
        if ($('#'+id+"_type_"+lp).val() == "BUY") {
            //buy then current price = buy price
            // console.log("in BUY");
            v = parseFloat(parseFloat($("#" + id + "_bp_" + lp).text()).toFixed(2));
            F = parseFloat(parseFloat(price).toFixed(2));
        }
        else {
            // console.log("in sell");
            v = parseFloat(parseFloat(price).toFixed(2));
            F = parseFloat(parseFloat($("#" + id + "_sp_" + lp).text()).toFixed(2));
        }
        y = parseFloat(parseFloat($("#" + id + "_qty_" + lp).text()).toFixed(2));
        // console.log("bp = "+v+"\n sp="+F+"\nquantity="+y);
        var t = 1.5, e = 1.5;

        var o = v * y * 0.0001 > 20 ? 20 : parseFloat(parseFloat(v * y * 0.0001).toFixed(2)),
            a = F * y * 0.0001 > 20 ? 20 : parseFloat(parseFloat(F * y * 0.0001).toFixed(2)),
            i = parseFloat(parseFloat(o + a).toFixed(2)),
            n = parseFloat(parseFloat((v + F) * y).toFixed(2)),
            r = Math.round(parseFloat(parseFloat(F * y * 0.00025).toFixed(2))),
            s = parseFloat(parseFloat(325e-7 * n).toFixed(2)),
            l = 0,
            c = parseFloat(parseFloat(.18 * (i + s)).toFixed(2)),
            p = parseFloat(parseFloat(1e-6 * n).toFixed(2)),
            // d = parseFloat(parseFloat(i + r + s + l + c + p).toFixed(2)),
            d = parseFloat(parseFloat(i + r + s + l + c + p).toFixed(2)),
            u = parseFloat(parseFloat(d / y).toFixed(2));
        sd = parseFloat(parseFloat(d * 0.2).toFixed(2));
        u = isNaN(u) ? 0 : u;
        var np = parseFloat(parseFloat((F - v) * y - d - sd).toFixed(2));

        $("#" + id + "_np_" + lp).text(np);

        if(np < 0)
        {
            if($('#npcolor_'+id).hasClass('alert-success'))
            {
                $('#npcolor_'+id).removeClass('alert-success');
            }
            $('#npcolor_'+id).addClass('alert-danger');
        }
        else if(np >= 0){
            if($('#npcolor_'+id).hasClass('alert-danger'))
            {
                $('#npcolor_'+id).removeClass('alert-danger');
            }
            $('#npcolor_'+id).addClass('alert-success');
        }

    }
}

function calc(id, price) {
    var v, f, y;

    var type = $('#type_' + id).val();
    // console.log("type"+type);
    if (type == "BUY") {
        //buy then current price = buy price
        // $("#" + id + "sp").text(price);
        v = parseFloat(parseFloat($("#" + id + "bp").text()).toFixed(2));
        F = parseFloat(parseFloat(price).toFixed(2));
    }
    else {
        // $("#" + id + "bp").text(price);
        v = parseFloat(parseFloat(price).toFixed(2));
        F = parseFloat(parseFloat($("#" + id + "sp").text()).toFixed(2));
    }

    y = parseFloat(parseFloat($("#" + id + "qty").text()).toFixed(2));
    var t = 1.5, e = 1.5;

    var o = v * y * 0.0001 > 20 ? 20 : parseFloat(parseFloat(v * y * 0.0001).toFixed(2)),
        a = F * y * 0.0001 > 20 ? 20 : parseFloat(parseFloat(F * y * 0.0001).toFixed(2)),
        i = parseFloat(parseFloat(o + a).toFixed(2)),
        n = parseFloat(parseFloat((v + F) * y).toFixed(2)),
        r = Math.round(parseFloat(parseFloat(F * y * 0.00025).toFixed(2))),
        s = parseFloat(parseFloat(325e-7 * n).toFixed(2)),
        l = 0,
        c = parseFloat(parseFloat(.18 * (i + s)).toFixed(2)),
        p = parseFloat(parseFloat(1e-6 * n).toFixed(2)),
        d = parseFloat(parseFloat( i + r + s + l + c + p).toFixed(2)),
        u = parseFloat(parseFloat(d / y).toFixed(2));
    sd = parseFloat(parseFloat(d * 0.2).toFixed(2));
    u = isNaN(u) ? 0 : u;
    var np = parseFloat(parseFloat((F - v) * y - d - sd).toFixed(2));

    // console.log(id+"="+np);
    $("#" + id + "np").text(np);
    // console.log(np);
    if(np < 0)
    {
        if($('.npcolor').hasClass('alert-success'))
        {
            $('.npcolor').removeClass('alert-success');
        }
        $('.npcolor').addClass('alert-danger');
    }
    else if(np >= 0){
        if($('.npcolor').hasClass('alert-danger'))
        {
            $('.npcolor').removeClass('alert-danger');
        }
        $('.npcolor').addClass('alert-success');
    }
}

// function graph() {
//     var date1, date2;

//     date1 = new Date(1577971000);
//     document.write("" + date1);

//     date2 = new Date(1578971000);
//     document.write("<br>" + date2);

//     var res = Math.abs(date1 - date2) / 1000;

//     // get hours        
//     var hours = Math.floor(res / 3600) % 24;
//     document.write("<br>Difference (Hours): " + hours);

//     // get minutes
//     var minutes = Math.floor(res / 60) % 60;
//     document.write("<br>Difference (Minutes): " + minutes);

//     // get seconds
//     var seconds = res % 60;
//     document.write("<br>Difference (Seconds): " + seconds);
// }