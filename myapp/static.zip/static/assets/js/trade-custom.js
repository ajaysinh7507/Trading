$(document).ready(function () { 

    function checkSelectedScript() {
        var script = localStorage.getItem('selectedScript');

        console.log(`Selected Script : ${script}`)
        $('.'+script).addClass('selected-script');
    }

    checkSelectedScript();



    $('.script-list > tbody > tr').click(function(e) {

        var script = localStorage.getItem('selectedScript');

        if($(this).hasClass('selected-script')) {
            $(this).removeClass('selected-script');
            localStorage.setItem('selectedScript','null');
        } else {
            $(this).addClass('selected-script');
            
            localStorage.setItem('selectedScript',$(this).data('name'));
        }
    })

    $(document).keypress(function(e) {
        // alert(e.keyCode);
        console.log(e.keyCode);
        // if(e.which == 13) {
        //     alert('You pressed enter!');
        // }

        if(e.which == 98) {
            e.preventDefault();
            showTradeModal('buy')
        }

        if(e.which == 115) {
            e.preventDefault();
            showTradeModal('sell')
        }
        
        if(e.which == 109) {
            e.preventDefault();
            var priceInput = $('.price-input');

            console.log("AAA",priceInput.data('disabled'))

            if(!priceInput.data('disabled')) {
                console.log("HERE 1" )
                priceInput.attr('disabled', 'disabled')
                priceInput.attr('data-disabled',"true");
            } else {
                console.log("HERE 2" )
                priceInput.removeAttr('disabled')
                priceInput.attr('data-disabled',"false");
            }
        }

    });

    $(document).on('keyup',function(evt) {
        if (evt.keyCode == 27) {
            closeTradeModal()
        }
    });


    $(document).on('click', '[class^="trade-btn"]', function(e) {
        var type = $(this).data('transaction-type');
        // alert(type);
        showTradeModal($(this))
    });

    function showTradeModal($this) {
        $('#market_radio').trigger('click');

        var type = $this.data('transaction-type');
        var script_name = $this.data('script_name');
        var instrument_token = $this.data('instrument_token');

        var typeElement = $('.transaction-type');
        var modalElement = $('#purchase-modal');
        var modalHeader = $('.trade-modal-header');
        var modalTradeBtn = $('.modal-trade-btn');
        var transactionType = $('input[name=modal_transaction_type_input]');
        var priceInput = $('.price-input');
        
        $('.transaction-script-name').html(script_name);
        $('input[name=modal_tradingsymbol_input]').val(script_name);
        $('.market-price').attr('class', `market-price ${instrument_token}_text`);

        if(type=="buy") {
            modalTradeBtn.attr('data-transaction-type',"buy");
            modalTradeBtn.removeClass('sell-btn');
            modalTradeBtn.addClass('buy-btn');
            modalTradeBtn.html('Buy')
            transactionType.val('Buy');
        } else {
            modalTradeBtn.attr('data-transaction-type',"sell");
            modalTradeBtn.removeClass('buy-btn');
            modalTradeBtn.addClass('sell-btn');
            modalTradeBtn.html('Sell');
            transactionType.val('Sell');
        }

        typeElement.text(type)
        typeElement.css('text-transform', 'capitalize')
        modalHeader.css('background',type=="buy" ? '#4184f3' : '#ff5722');
        modalElement.slideDown('fast');
        modalElement.css('display', 'flex');
        priceInput.focus();
        priceInput.select();
    }


    $('.close-modal').click(function(e) {
        closeTradeModal()
    })

    function closeTradeModal() {
        var modalElement = $('#purchase-modal');
        modalElement.slideUp('fast');
    }


})